class Pages_Android:
    def __init__(self, UI):
        self._UI = UI


