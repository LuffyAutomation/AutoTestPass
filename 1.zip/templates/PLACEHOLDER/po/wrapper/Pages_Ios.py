class Pages_Ios:
    def __init__(self, UI):
        self._UI = UI